/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import dbHelpers.ReadQuery;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Class responsible for data access operations (DAO) related to FoodItem.
 */

public class FoodItemDAO {
    // Utilizing ReadQuery for executing database queries.
    private final ReadQuery readQuery;

    // Constructor to initialize ReadQuery for database operations.
    public FoodItemDAO() throws SQLException {
        this.readQuery = new ReadQuery();
    }

     // Method to search dishes based on a search term.
    public List<FoodItem> searchDishes(String searchTerm) throws SQLException {
        List<FoodItem> dishes = new ArrayList<>();
        // SQL query to fetch dishes based on a search term.
        String query = "SELECT FoodItemID, FoodItemName, Price, LinkToFoodImage FROM craveconnect.FoodItem WHERE FoodItemName LIKE ?";
        List<Object> params = new ArrayList<>();
        params.add("%" + searchTerm + "%");

        // Executing the query and processing the result set.
        try (ResultSet results = readQuery.readTableDataWithParameters(query, params)) {
            while (results.next()) {
                 // Extracting FoodItem attributes from the result set.
                int foodItemId = results.getInt("FoodItemID");
                String name = results.getString("FoodItemName");
                double price = results.getDouble("Price");
                String imageUrl = results.getString("LinkToFoodImage");

                // Creating a FoodItem object and setting its ingredients.
                FoodItem item = new FoodItem(name, price, imageUrl);
                List<String> ingredients = getIngredientsForFoodItem(foodItemId);
                item.setIngredients(ingredients);
                dishes.add(item);
            }
        } catch (SQLException e) {
            // Handling SQL errors.
        } finally {
            //Closing the database connection.
            readQuery.disconnect();
        }

        return dishes;
    }
    
    // Method to search dishes based on category ID.
    public List<FoodItem> searchDishesByCategory(String categoryId) throws SQLException {
        List<FoodItem> dishes = new ArrayList<>();
        // SQL query to fetch dishes based on category ID.
        String query = "SELECT FoodItemID, FoodItemName, Price, LinkToFoodImage FROM craveconnect.FoodItem WHERE FoodItemCategoryID = ?";
        List<Object> params = new ArrayList<>();
        params.add(categoryId);

        // Executing the query and processing the result set.
        try (ResultSet results = readQuery.readTableDataWithParameters(query, params)) {
            while (results.next()) {
                 // Similar extraction and object creation as in searchDishes method.
                int foodItemId = results.getInt("FoodItemID");
                String name = results.getString("FoodItemName");
                double price = results.getDouble("Price");
                String imageUrl = results.getString("LinkToFoodImage");

                FoodItem item = new FoodItem(name, price, imageUrl);
                List<String> ingredients = getIngredientsForFoodItem(foodItemId);
                item.setIngredients(ingredients);
                dishes.add(item);
            }
        } catch (SQLException e) {
            // Handling SQL errors.
        } finally {
            // Closing the database connection.
            readQuery.disconnect();
        }

        return dishes;
    }

     // Method to get ingredients for a specific dish.
    private List<String> getIngredientsForFoodItem(int foodItemId) throws SQLException {
        List<String> ingredients = new ArrayList<>();
        // INNER JOIN between Ingredients and FoodItemIngredients tables to fetch names of ingredients associated with a specific food item.
        String query = "SELECT i.IngredientName " +
                       "FROM Ingredients i " +
                       "JOIN FoodItemIngredients fi ON i.IngredientID = fi.IngredientID " +
                       "WHERE fi.FoodItemID = ?";
        List<Object> params = new ArrayList<>();
        params.add(foodItemId);
        
        // Executing the query and adding ingredients to the list.
        try (ResultSet results = readQuery.readTableDataWithParameters(query, params)) {
            while (results.next()) {
                ingredients.add(results.getString("IngredientName"));
            }
        }

        return ingredients;
    }
}
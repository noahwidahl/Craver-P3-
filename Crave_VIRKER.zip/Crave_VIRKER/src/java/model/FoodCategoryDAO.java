package model;

import dbHelpers.ReadQuery;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Class responsible for data access operations (DAO) related to FoodCategory.
 */
public class FoodCategoryDAO {
    
    public List<FoodCategory> getAllCategories() throws SQLException {
        List<FoodCategory> categories = new ArrayList<>();

        // Creating an instance of ReadQuery to facilitate database interaction.
        ReadQuery readQuery = new ReadQuery();
        String query = "SELECT * FROM FoodCategory";

        try (ResultSet results = readQuery.readCategories()) {
            // Looping through the ResultSet to extract category data.
            while (results.next()) {
                // Extracting category ID and description from the current row.
                int categoryId = results.getInt("FoodItemCategoryID");
                String categoryDescription = results.getString("FoodItemDescription");

                // Creating a new FoodCategory object and adding it to the list.
                FoodCategory category = new FoodCategory(categoryId, categoryDescription);
                categories.add(category);
            }
        } catch (SQLException e) {
            // Handling any SQL related exceptions.
        } finally {
            // Closing database connection.
            readQuery.disconnect();
        }

        return categories;
    }
}

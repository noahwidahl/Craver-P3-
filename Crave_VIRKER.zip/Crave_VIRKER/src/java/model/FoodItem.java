package model;

import java.util.List;

/**
 * Represents a food item with name, price, image URL and ingredients.
 */

public class FoodItem {
    private String name;
    private double price;
    private String imageUrl;
    private List<String> ingredients;

    // Constructor
    public FoodItem(String fooditemname, double price, String linktofoodimage) {
        this.name = fooditemname;   // Setting the food item's name.
        this.price = price;         // Setting the food item's price.
        this.imageUrl = linktofoodimage; // Setting the URL for the food item's image.
    }

    // Getter and setter for 'name'
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    // Getter and setter for 'price'
    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    // Getter and setter for 'imageUrl'
    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }
    
    // Getter and setter for ingredients
    public List<String> getIngredients() {
        return ingredients;
    }

    public void setIngredients(List<String> ingredients) {
        this.ingredients = ingredients;
    }
}

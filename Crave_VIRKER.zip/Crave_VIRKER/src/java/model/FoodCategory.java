/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 * Represents a category of food items.
 */

public class FoodCategory {
    private int foodItemCategoryID; // Unique identifier for the food category.
    private String foodItemDescription; // Description or name of the food category.

    public FoodCategory(int foodItemCategoryID, String foodItemDescription) {
        this.foodItemCategoryID = foodItemCategoryID; // Setting the category's unique ID.
        this.foodItemDescription = foodItemDescription; // Setting the category's description.
    }
    
// Getters
    public int getFoodItemCategoryID() {
        return foodItemCategoryID;
    }

    public String getFoodItemDescription() {
        return foodItemDescription;
    }

    // Setters
    public void setFoodItemCategoryID(int foodItemCategoryID) {
        this.foodItemCategoryID = foodItemCategoryID;
    }

    public void setFoodItemDescription(String foodItemDescription) {
        this.foodItemDescription = foodItemDescription;
    }
}